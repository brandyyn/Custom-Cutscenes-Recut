There may or may not be errors.. I am slowly adding tutorials to http://minecraft.curseforge.com/mc-mods/235069-custom-cutscenes/pages/custom-cutscenes

NOTE: Version 0.0.5 Alpha - Moved the Assets folder from config folder, back to the root folder. The folder is named "custom-cutscene-files".
Like I have said this mod is in alpha, I may change things from time to time. Give me feedback, As I will do
what ever I can to make this mod easy.

I have moved the assets folder because, now the mod will create a custom jar that will hold all of the files
in the new folder. Once you have every file you want added (as of now is only images and sounds).  Go Under the Config Dir and edit 
"custom_cutscenes.cfg" change "reload_assets_on_load" to equal "false". You have to do this before you release your said modpack
If you don't those files will get overwritten the first time a person plays your modpack. But this allows you to just include the 
"custom_cutscene_files.jar" in your modpack as it contains all your cutscene images/sounds. 

Your Update Check List:

1. Backup your config & assets files
2. delete the originals
3. run the mod (Example Cut scene images may not show)
4. If you reload the game the images should show
5. View Example mod for any changes
6. Make changes to your files (if you don't you may experience a crash)
7. copy your files to correct folders
8. and your done.. your cut scene will load. (Note: You may have to reload the game to see images again)
