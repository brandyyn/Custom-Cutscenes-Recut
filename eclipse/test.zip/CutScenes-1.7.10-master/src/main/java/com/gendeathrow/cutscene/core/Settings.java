package com.gendeathrow.cutscene.core;


public class Settings 
{

	
	public static boolean update_resources = true;
	public static boolean dev_Enviroment = true;
	
	public static boolean trigger_OnPlayer_Login = false;
	public static boolean trigger_OnPlayer_Login_Always = false;
	public static String file_OnPlayer_Login = "login.json";
	
	
	public static boolean hasPlayedSeenLogin = false;
	
	public static boolean trigger_OnPlayer_Death = false;
	public static String file_OnPlayer_Death = "death.json";
	
}
